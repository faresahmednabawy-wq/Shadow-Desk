# بناء ShadowDesk APK من الموبايل فقط

## تجهيز الملف
1. أنشئ حسابًا في GitHub وسجّل الدخول من Chrome.
2. افتح https://github.com/new وأنشئ مستودعًا جديدًا باسم `ShadowDesk`، ويمكن جعله Private.
3. فك ضغط `ShadowDesk_Android_Project.zip` باستخدام مدير الملفات في الهاتف.
4. ارفع محتويات مجلد `ShadowDesk_Android_Project` إلى جذر المستودع (لا ترفع المجلد الخارجي نفسه كمجلد متداخل). تأكد من ظهور `app`, `build.gradle`, `settings.gradle` و`.github/workflows/build-apk.yml` في الجذر.
5. في GitHub افتح تبويب **Actions**. إذا طُلب منك تفعيل Actions ففعّله.
6. اختر **Build ShadowDesk APK** ثم **Run workflow** ثم زر **Run workflow** الأخضر.
7. انتظر انتهاء المهمة بعلامة نجاح. افتح تشغيل المهمة، وانزل إلى **Artifacts**، ثم حمّل `ShadowDesk-debug-apk`.
8. فك ضغط ملف Artifact المحمّل، وستجد `app-debug.apk`. اضغط عليه للتثبيت، واسمح بالتثبيت من Chrome أو مدير الملفات عند طلب أندرويد ذلك.

## ملاحظات
- عملية البناء تتم على خوادم GitHub؛ الهاتف يستخدم لرفع الملفات وتشغيل البناء وتنزيل الناتج.
- هذا APK تجريبي (debug)، وليس إصدارًا منشورًا على Google Play.
- لا تضع كلمات مرور أو مفاتيح توقيع في ملفات المستودع.
- لم يتم اختبار نجاح البناء مسبقًا في بيئة إنشاء هذه الحزمة؛ إذا فشل GitHub Actions، افتح سجل المهمة وأرسل رسالة الخطأ.
