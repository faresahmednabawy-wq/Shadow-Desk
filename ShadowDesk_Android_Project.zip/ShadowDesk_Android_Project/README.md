# ShadowDesk — Android project (source)

A bilingual (Arabic/English) original digital-investigation game prototype inspired by the genre, not a copy of The Operator 2.

## Features
- Landscape-first interface, suitable for touch screens
- Arabic and English UI toggle
- Fictional cases, evidence board, suspect profiles, terminal puzzles
- Local save using browser storage
- No network access and no real-system hacking

## Build an APK
This environment did not have the Android SDK or Gradle installed, so no APK has been compiled or tested here.

1. Install Android Studio on a computer.
2. Open this folder (`ShadowDesk_Android_Project`) as an existing project.
3. Let Android Studio download the Gradle/Android Gradle Plugin dependencies.
4. Install Android SDK Platform 35 from SDK Manager.
5. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio will show the generated APK location (usually `app/build/outputs/apk/debug/app-debug.apk`).
7. Copy the APK to your Android phone and install it. You may need to allow installs from that file manager.

If Gradle sync fails due to version compatibility, use the Gradle/Android Gradle Plugin versions recommended by your installed Android Studio.

## Status
Source project assembled; APK build and device testing have NOT been performed in this environment.
